var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Category;
(function (Category) {
    Category[Category["AutoBiography"] = 0] = "AutoBiography";
    Category[Category["Comedy"] = 1] = "Comedy";
    Category[Category["Inspirational"] = 2] = "Inspirational";
    Category[Category["Fiction"] = 3] = "Fiction";
})(Category || (Category = {}));
function GetAllBooks() {
    var books = [
        { title: 'Wings Of Fire', price: 300, author: 'Dr. APJ Abdul Kalam', available: false, category: Category.Inspirational },
        { title: 'I am Malala', price: 700, author: 'Malala', available: false, category: Category.AutoBiography },
        { title: 'Playing It My Way', price: 300, author: 'Sachin Tendulkar', available: true, category: Category.AutoBiography },
        { title: 'Mrutunjay', price: 600, author: 'Ranjit Desai', available: false, category: Category.Fiction },
        { title: 'Chava', price: 300, author: 'Ranjit Desai', available: true, category: Category.Fiction }
    ];
    return books;
}
var allBooks = GetAllBooks();
for (var _i = 0, allBooks_1 = allBooks; _i < allBooks_1.length; _i++) {
    var book = allBooks_1[_i];
    console.log(book.title + " costs Rs." + book.price + " , Category : " + Category[book.category]);
}
function GetBooksByCategory(categoryFilter) {
    console.log('Getting books for Category : ' + Category[categoryFilter]);
    var filteredBooks = [];
    for (var _i = 0, allBooks_2 = allBooks; _i < allBooks_2.length; _i++) {
        var currBook = allBooks_2[_i];
        if (currBook.category === categoryFilter) {
            filteredBooks.push(currBook.title);
        }
    }
    return filteredBooks;
}
var biographyBooks = GetBooksByCategory(Category.AutoBiography);
// Optional Parameters
// function Print(title:string,noOfPages:number,printType?:string){
//         console.log(title,noOfPages,printType)
// }
//  Print('Playing It My Way',600);
// Default Parameters
// function Print(title:string="Unknown",noOfPages:number,printType:string="B/W"){
//     console.log(title,noOfPages,printType);
// }
//Print(undefined,900);
// Rest Parameters
function Print(author) {
    var restArgs = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        restArgs[_i - 1] = arguments[_i];
    }
    console.log(author, restArgs);
}
Print("Don Shori", 'Kyting', 'Wells Well');
Print("Ramanuj", 'Pratigya');
Print('Malala');
var IdGenerator; // Function Type !
IdGenerator = ProductIdGenerator;
IdGenerator(10, 'ABC');
function ProductIdGenerator(id, name) {
    return id + name;
}
function EmpIdGenerator(id, name) {
    return 'EMP_' + id + name;
}
IdGenerator = EmpIdGenerator;
IdGenerator(20, 'XYZ');
var cars = ['BMW', 'Audi', 'Honda', 'Peugot'];
var moreCars = ['Hyundai', 'Tata', 'Mahindra'];
var allCars = cars.concat(['Fiat'], moreCars); // Spread operator !
// Destructuring
// with Array
var car1, car2, car3, car4;
// [car1,car2,car3,car4='Unknown'] = cars;
car1 = cars[0], car3 = cars[2];
console.log(car1, car3);
// with Objects
var Name, Age, RunsScored;
var person = { Name: 'Sachin', City: 'Mumbai', Age: 43 };
(Age = person.Age, Name = person.Name, RunsScored = person.RunsScored);
function GetTitles(bookProperty, author) {
    var booksToBeReturned = [];
    if (typeof bookProperty == "boolean") {
        for (var _i = 0, allBooks_3 = allBooks; _i < allBooks_3.length; _i++) {
            var book = allBooks_3[_i];
            if (book.available == bookProperty) {
                booksToBeReturned.push(book.title);
            }
        }
    }
    return booksToBeReturned;
}
var p;
p = {
    name: 'Sachin',
    age: 43,
    getDetails: function () {
        console.log(this.name + ' : ' + this.age);
    }
};
p.getDetails();
var Car = /** @class */ (function () {
    function Car(theName, theSpeed) {
        this.name = theName;
        this.speed = theSpeed;
    }
    Car.prototype.Accelerate = function (theCurrSpeed) {
        return this.name + " is running at " + theCurrSpeed + " kmph !";
    };
    return Car;
}());
//     var carObj = new Car("i20",200)
//    console.log(carObj.Accelerate(300));
//    console.log(carObj.name);
var SportsCar = /** @class */ (function (_super) {
    __extends(SportsCar, _super);
    function SportsCar(theName, theSpeed, theNitroPower) {
        var _this = _super.call(this, theName, theSpeed) || this;
        _this.useNitro = theNitroPower;
        return _this;
    }
    SportsCar.prototype.Accelerate = function (theCurrSpeed) {
        return _super.prototype.Accelerate.call(this, this.speed) + " Use Ntro Power ? " + this.useNitro;
    };
    return SportsCar;
}(Car));
var spCar = new SportsCar("Ferrari", 500, true);
var Employee = /** @class */ (function () {
    function Employee(name, salary) {
    }
    return Employee;
}());
var e = new Employee();
var Person = /** @class */ (function () {
    function Person() {
    }
    Person.prototype.getDetails = function () {
        // console.log(this.name + " is of " + this.age + " years !");
        console.log(this.name + " is of " + this.age + "  years !");
    };
    return Person;
}());
function Swap(x, y) {
    var temp;
    temp = x;
    x = y;
    y = temp;
}
Swap(20, 50);
Swap('Hello !', 'Bye !');
var Point = /** @class */ (function () {
    function Point(x, y) {
        this.x = x;
        this.y = y;
    }
    return Point;
}());
var point = new Point(10, '3.0f');
console.log(typeof point.x);
var Emp = /** @class */ (function () {
    function Emp() {
    }
    return Emp;
}());
var Manager = /** @class */ (function (_super) {
    __extends(Manager, _super);
    function Manager() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return Manager;
}(Emp));
var ActingManager = /** @class */ (function () {
    function ActingManager() {
    }
    return ActingManager;
}());
var Company = /** @class */ (function () {
    function Company() {
    }
    return Company;
}());
// var c = new Company<ActingManager>();
// tuples
var tupleVar;
tupleVar = ["Hyderabad", 1, 457656];
console.log(tupleVar[0]);
var arr = [[10, 20], [30, 40]];
var arrayOfTuples;
