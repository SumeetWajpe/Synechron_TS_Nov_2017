
enum Category{
    AutoBiography,
    Comedy,
    Inspirational,
    Fiction
}

interface IBook{
    title:string;
    author:string;
    price:number;
    available:boolean;
    category:Category;
}

function GetAllBooks():IBook[]{
    let books:IBook[]=[
        {title:'Wings Of Fire',price:300,author:'Dr. APJ Abdul Kalam',available:false,category:Category.Inspirational},
        {title:'I am Malala',price:700,author:'Malala',available:false,category
    :Category.AutoBiography},
        {title:'Playing It My Way',price:300,author:'Sachin Tendulkar',available:true,category
        :Category.AutoBiography},
        {title:'Mrutunjay',price:600,author:'Ranjit Desai',available:false,category
        :Category.Fiction},
        {title:'Chava',price:300,author:'Ranjit Desai',available:true,category
        :Category.Fiction}
        ];
     return books;
}

let allBooks:IBook[] = GetAllBooks();

for(let book of allBooks){
    console.log(book.title + " costs Rs." + book.price + " , Category : " + Category[book.category]);
}



function    GetBooksByCategory(categoryFilter:Category):string[]{
    console.log('Getting books for Category : ' + Category[categoryFilter]);
    let filteredBooks:string[] = [];
        for(let currBook of allBooks){
            if(currBook.category === categoryFilter){
                filteredBooks.push(currBook.title);
            }
        }
    return filteredBooks;
    }
    
    let biographyBooks: string[] = GetBooksByCategory(Category.AutoBiography);


    // Optional Parameters
    // function Print(title:string,noOfPages:number,printType?:string){
    //         console.log(title,noOfPages,printType)
    // }

    //  Print('Playing It My Way',600);

    // Default Parameters

    // function Print(title:string="Unknown",noOfPages:number,printType:string="B/W"){
    //     console.log(title,noOfPages,printType);
    // }

    //Print(undefined,900);

    // Rest Parameters
    function Print(author:string,...restArgs:string[]){
        console.log(author,restArgs);
    }

    Print("Don Shori",'Kyting','Wells Well');
    Print("Ramanuj",'Pratigya');
    Print('Malala');



var IdGenerator:(str_id:number,str_name:string) => string; // Function Type !

IdGenerator = ProductIdGenerator;
IdGenerator(10,'ABC');


    function ProductIdGenerator(id:number,name:string):string{
        return id + name;
    }

    function EmpIdGenerator(id:number,name:string):string{
        return 'EMP_' + id  + name;
    }

    IdGenerator = EmpIdGenerator;
    IdGenerator(20,'XYZ');

    var cars:string[] = ['BMW','Audi','Honda','Peugot'];
    var moreCars:string[] = ['Hyundai','Tata','Mahindra'];
    let allCars:string[] = [...cars,'Fiat',...moreCars]; // Spread operator !

    // Destructuring
 // with Array
    var car1,car2,car3,car4;

    // [car1,car2,car3,car4='Unknown'] = cars;
    [car1,,car3] = cars;
    
    console.log(car1,car3);

    // with Objects

    var Name,Age,RunsScored;    
    var person:any = {Name:'Sachin',City:'Mumbai',Age:43};

    ({Age,Name,RunsScored} = person);

    // OOP
    function GetTitles(availability:boolean,author:string):string[];
   function GetTitles(categoryFilter:Category):string[];
   function GetTitles(bookProperty:any,author?:string):string[]   {

    let booksToBeReturned:string[] = [];

    if(typeof bookProperty == "boolean"){
        for (let book of allBooks) {
                if(book.available == bookProperty){
                    booksToBeReturned.push(book.title);
                }
        }
    }

               return booksToBeReturned;
   }

   //GetTitles()

   // Interfaces 

   interface IPerson{
       name:string;
       age:number;
       email?:string;
       getDetails:()=>void;
   }

   let p:IPerson;

   p= {
       name:'Sachin',
        age:43,
        getDetails:function(){
       console.log(this.name+ ' : ' + this.age);
      }
    };

      p.getDetails();


      class Car{
          name:string;
          speed:number;

          constructor(theName:string,theSpeed:number){
                this.name = theName;
                this.speed = theSpeed;
          }

          Accelerate(theCurrSpeed:number):string{
                return this.name + " is running at " + theCurrSpeed + " kmph !"
          }
      }

    //     var carObj = new Car("i20",200)
    //    console.log(carObj.Accelerate(300));
    //    console.log(carObj.name);


    class SportsCar extends Car{
            useNitro:boolean;
            constructor(theName:string,theSpeed:number,theNitroPower:boolean){
                        super(theName,theSpeed);
                        this.useNitro = theNitroPower;
            }

            Accelerate(theCurrSpeed:number):string{
                return super.Accelerate(this.speed) + " Use Ntro Power ? "  + this.useNitro
          }
    }

    var spCar = new SportsCar("Ferrari",500,true);

    class Employee{
        constructor(name?:string, salary?:number){

        }
    }

    var e = new Employee();
    

    class Person implements IPerson{
            name:string;
            age:number;
            getDetails():void{
               // console.log(this.name + " is of " + this.age + " years !");
               console.log(`${this.name} is of ${this.age}  years !`)
            }
    }



    function Swap<T>(x:T,y:T){
            let temp:T;

            temp = x;
            x = y;
            y = temp;
    }

    Swap<number>(20,50);
    Swap<string>('Hello !','Bye !');

    class Point<T,V>{      
        constructor(public x:T,private y:V){

        }

        // Swap(x:T,y:V){

        // }
    }
    
    let point:Point<number,string> = new Point<number,string>(10,'3.0f');

    console.log(typeof point.x);

    class Emp{
        name:string;
    }

    class Manager extends Emp{
        salary:number;
    }

    class ActingManager{     
        age:number;
    }

    class Company<T extends Emp>{

    }

   // var c = new Company<ActingManager>();

   // tuples

   let tupleVar:[string,number,number];
   tupleVar = ["Hyderabad",1,457656];
   console.log(tupleVar[0]);


   var arr:Array<[number,number]> = [[10,20],[30,40]];

   var arrayOfTuples:[number,string][];
   