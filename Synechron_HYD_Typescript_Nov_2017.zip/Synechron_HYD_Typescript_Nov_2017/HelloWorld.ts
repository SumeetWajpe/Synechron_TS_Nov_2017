var str = "Hello World !"; // type inference
console.log(str);
//str =100;
var x:number ;// type annotation
var s:string|number;
s = "BYe World !";
s = 100;
let b:boolean;
// 100lines 
// let b:boolean;
var anyType:any;
anyType = 10;
anyType = true;
anyType = {Name:'Synechron',Location:'HYD'};
var z;// implicitly any !

if(true){
    let letVariable = 2000;

    if(true){
        let anotherVar = 1000;
        console.log(letVariable);
    }
}

//console.log(letVariable); // Error !


// can't declare (must declare and define)
// const PI;
// PI = 3.14;

const PI = 3.14;
//PI = 3.1465;

function Add(x:number,y:number):number|string{
    if(x>10){
        return x + y;    
    }
    else{
    return 'X Value smaller than 10 !';
    
    }
}

var result:number|string = Add(10,20);

// function Square(x:number):void{
//     console.log(x*x);
// }


// Function as an Expression !
var Square = function(x:number):number{
        return x*x;
}

var Square = (x:number):number => x * x;

console.log(Square(10));

function Car(){
    this.Name = "i20";
   
    setTimeout(()=>{ 
        console.log(this.Name);
    },2000)
}

enum Designations{
    Trainer = 100,
    Developer,
    Tester,
    Architect
}

let myDesignation:Designations;

myDesignation = Designations.Developer;

console.log(myDesignation);
console.log(Designations[myDesignation]);

var cars:string[] = ['BMW','Audi','Honda'];
var moreCars:Array<string> = new Array<string>();// using Generics


for(let car in cars){
    console.log(cars[car]);
}

for(let car of cars){
    console.log(car);
}

var Company:any[] = [{Name:'Synechron',Location:'Hyd'},{Name:'Synechron',Location:'Pune'},{Name:'Synechron',Location:'Beng'}]