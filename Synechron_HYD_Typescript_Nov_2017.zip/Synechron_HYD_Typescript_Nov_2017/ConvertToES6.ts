const x:number = 100;

function Add(x:any,y:any){
    return x + y;
}