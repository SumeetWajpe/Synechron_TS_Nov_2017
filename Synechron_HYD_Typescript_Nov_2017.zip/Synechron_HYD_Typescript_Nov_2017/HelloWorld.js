var str = "Hello World !"; // type inference
console.log(str);
//str =100;
var x; // type annotation
var s;
s = "BYe World !";
s = 100;
var b;
// 100lines 
// let b:boolean;
var anyType;
anyType = 10;
anyType = true;
anyType = { Name: 'Synechron', Location: 'HYD' };
var z; // implicitly any !
if (true) {
    var letVariable = 2000;
    if (true) {
        var anotherVar = 1000;
        console.log(letVariable);
    }
}
//console.log(letVariable); // Error !
// can't declare (must declare and define)
// const PI;
// PI = 3.14;
var PI = 3.14;
//PI = 3.1465;
function Add(x, y) {
    if (x > 10) {
        return x + y;
    }
    else {
        return 'X Value smaller than 10 !';
    }
}
var result = Add(10, 20);
// function Square(x:number):void{
//     console.log(x*x);
// }
// Function as an Expression !
var Square = function (x) {
    return x * x;
};
var Square = function (x) { return x * x; };
console.log(Square(10));
function Car() {
    var _this = this;
    this.Name = "i20";
    setTimeout(function () {
        console.log(_this.Name);
    }, 2000);
}
var Designations;
(function (Designations) {
    Designations[Designations["Trainer"] = 100] = "Trainer";
    Designations[Designations["Developer"] = 101] = "Developer";
    Designations[Designations["Tester"] = 102] = "Tester";
    Designations[Designations["Architect"] = 103] = "Architect";
})(Designations || (Designations = {}));
var myDesignation;
myDesignation = Designations.Developer;
console.log(myDesignation);
console.log(Designations[myDesignation]);
var cars = ['BMW', 'Audi', 'Honda'];
var moreCars = new Array(); // using Generics
for (var car in cars) {
    console.log(cars[car]);
}
for (var _i = 0, cars_1 = cars; _i < cars_1.length; _i++) {
    var car = cars_1[_i];
    console.log(car);
}
