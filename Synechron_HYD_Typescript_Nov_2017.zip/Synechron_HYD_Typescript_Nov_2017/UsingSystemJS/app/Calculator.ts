import Addition from './Math';

console.log('The addition is : ' + Addition(20,30))