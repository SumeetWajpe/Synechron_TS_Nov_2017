 function Addition(x:number,y:number):number{
    return x + y;
}

export default Addition;

