"use strict";
exports.__esModule = true;
function Addition(x, y) {
    return x + y;
}
exports["default"] = Addition;
